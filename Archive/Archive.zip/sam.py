# Main Program
if __name__ == '__main__':

	# Load all of the required files
	# First file contains the text, rest are data
	file = open("text.txt", "r")
	vText = file.read().splitlines()

	file = open("punct.txt", "r")
	strPunct = file.read()

	file = open("chinese.txt", "r")
	strChinese = file.read()

	file = open("ipa.txt", "r")
	vIPA = file.read().splitlines()

	# Loop through lines in text
	n = len(vText)
	for i in range(n):
		strI = vText[i]
		if(len(strI) < 1):
			continue

		# Starting at end of line, look for first non-punctuation character
		iLast = len(strI)-1
		while strPunct.find(strI[iLast]) != -1:
			iLast -= 1

		# Get last non-punctuation character
		strSign = strI[iLast]
		iMatch = strChinese.find(strSign)

		# Find match in list of chinese characters and select IPA match
		# If character is not found, output NA
		strIPA = " {NA} "
		if iMatch >= 0:
			strIPA = "{" + vIPA[iMatch] + "}"

		vText[i] = strI[:iLast+1] + " " + strIPA + " " + strI[iLast+1:]
		vText[i] = strI + " " + strIPA

		print(vText[i])

	# Save annotated text to new file
	file = open("text_annotated.txt", "w")
	for strLine in vText:
		file.write("%s\n" % strLine)
